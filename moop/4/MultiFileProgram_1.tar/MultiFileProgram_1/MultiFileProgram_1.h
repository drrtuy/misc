#ifndef FUNCTIONS
#define FUNCTIONS

int getDigitSum(int a);

#endif
